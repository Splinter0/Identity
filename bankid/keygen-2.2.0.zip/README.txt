BankID Relying Party Certificate application

The BankID Keygen tool is used to create Relying Party Certificates (RP Certificates), certificate requests and PFX-files.
RP certificates are required for service providers to use the BankID service.

More information is available at https://www.bankid.com/bankid-keygen

Third party license information is available in LICENSE-3RD-PARTY.txt
